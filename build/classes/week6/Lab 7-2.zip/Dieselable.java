
/**
 * You can follow me on instagram!
 * https://www.instagram.com/few.pz/
 */

/**
 *
 * @author "FewPz (IG: few.pz")
 */
public interface Dieselable {
    
    public abstract void startEngine();
    public abstract void stopEngine();
    
}
