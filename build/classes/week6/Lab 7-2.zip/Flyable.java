
/**
 * You can follow me on instagram!
 * https://www.instagram.com/few.pz/
 */

/**
 *
 * @author "FewPz (IG: few.pz")
 */
public interface Flyable {
    
    public abstract void fly();
    public abstract void takeOff();
    public abstract void landing();
    
}
